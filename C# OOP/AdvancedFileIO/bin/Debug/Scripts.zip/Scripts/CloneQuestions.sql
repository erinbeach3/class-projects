DROP procedure if exists CloneQuestions;
DELIMITER $$
CREATE PROCEDURE CloneQuestions(quizId int, newQuizId int, targetCourseId int)
begin
    /* NOTE: No transaction.  This procedure is intended to be called only from CloneQuiz, which has a transaction. */
    /* NOTE: Target course must differ from origin course.  */
	declare done bool default false;
    declare qid, newQid, tid, n int default 0;
	declare qcur cursor for select question_id from c_quiz_rel_question where exercice_id=quizId;
    declare continue handler for NOT FOUND set done = true;
    SET SQL_SAFE_UPDATES = 0;
    create temporary table tmpCats as select * from c_quiz_question_category where iid in 
        (select category_id from c_quiz_question_rel_category where question_id in 
            (select question_id from c_quiz_rel_question where exercice_id=quizId));
    update tmpCats set c_id=targetCourseId;
    open qcur;
    read_loop: LOOP
		FETCH qcur into qid;
        if done=true then
			LEAVE read_loop;
        end if;
        /* c_quiz_question */
        insert into c_quiz_question (c_id, question, description, ponderation, position, type, picture, level, extra, question_code)
			select q.c_id, q.question, q.description, q.ponderation, q.position, q.type, q.picture, q.level, q.extra, q.question_code
            from c_quiz_question q
            where q.iid=qid;
		set newQid = last_insert_id();
        update c_quiz_question set c_id=targetCourseId, id=newQid where iid=newQid;
        
        insert into c_quiz_rel_question select null, targetCourseId, t.question_order, newQid, newQuizId from c_quiz_rel_question t
			where t.question_id=qid and t.exercice_id=quizId;
		/* NOTE: in practice, this table is not used: */
        insert into c_quiz_question_option select null, targetCourseId, newQid, t.name, t.position 
			from c_quiz_question_option t where t.question_id=qid;
        set n = row_count();
        if n > 0 then begin
			set tid = last_insert_id();
			update c_quiz_question_option set id=tid where iid=tid;
        end; end if;
        
        insert into c_quiz_question_rel_category select null, targetCourseId, t.category_id, newQid
			from c_quiz_question_rel_category t where t.question_id=qid;
            
        create temporary table tmp as select * from c_quiz_answer where question_id=qid;
        alter table tmp modify iid int NULL;
        update tmp set iid=null, c_id=targetCourseId, question_id=newQid;
        insert into c_quiz_answer select * from tmp;
        update c_quiz_answer set id=iid, id_auto=iid where question_id=newQid;
    END LOOP;
    CLOSE qcur;
end$$
DELIMITER ;
