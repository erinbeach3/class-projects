DROP procedure if exists DeleteQuiz;
DELIMITER $$
create procedure DeleteQuiz(quizId int) 
begin
    declare nQuizUsingQuestions int;
    declare EXIT HANDLER FOR SQLEXCEPTION
    begin
        /*
        GET DIAGNOSTICS CONDITION 1 @msg = MESSAGE_TEXT;
        select @msg as ErrorMsg;
        */
        select 'An error occurred.  Rolling back.' as Message;
        ROLLBACK;
    end;
    SET SQL_SAFE_UPDATES = 0;
    start TRANSACTION;
    /* Test whether questions are used by other existing quizzes.  If so, do not delete the Q/A: */
    set nQuizUsingQuestions = (select count(*) from (select distinct exercice_id from c_quiz_rel_question 
        where question_id in (select question_id from c_quiz_rel_question where exercice_id=quizId)) as t);
    if nQuizUsingQuestions == 1 then
    begin
        delete from c_quiz_answer 
            where question_id in (select question_id from c_quiz_rel_question where exercice_id=quizId);
        delete from c_quiz_question_option 
            where question_id in (select question_id from c_quiz_rel_question where exercice_id=quizId);
        delete from c_quiz_question_rel_category 
            where question_id in (select question_id from c_quiz_rel_question where exercice_id=quizId);
        delete from c_quiz_question 
            where iid in (select question_id from c_quiz_rel_question where exercice_id=quizId);
    end; end if;
    delete from c_quiz_rel_question where exercice_id=quizId;
    delete from c_quiz_rel_category where exercise_id=quizId;
    delete from c_quiz where iid=quizId;
    /* Only c_quiz_question_category is untouched */
    COMMIT;
end$$
DELIMITER ;