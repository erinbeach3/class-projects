DROP procedure if exists CloneQuiz;
DELIMITER $$
CREATE PROCEDURE `CloneQuiz`(quizId int, targetCourseId int)
proc_label: begin
    declare n, srcCourseId, newQuizId int;
    declare errMsg TEXT;
    declare EXIT HANDLER FOR SQLEXCEPTION
    begin
        /*
        GET DIAGNOSTICS CONDITION 1 @msg = MESSAGE_TEXT;
        select @msg as ErrorMsg;
        */
        select 'An error occurred.  Rolling back.' as Message;
        ROLLBACK;
    end;
    set n = (select count(*) from c_quiz where iid=quizId);
    if n<>1 then begin
        set errMsg = CONCAT('Quiz with id ', quizId, ' not found.');
        select errMsg as ErrorMessage;
        leave proc_label;
        /*signal SQLSTATE '45000' set MESSAGE_TEXT= errMsg;*/
    end; end if;
    set n = (select count(*) from course where id=targetCourseId);
    if n<>1 then begin
        set errMsg = CONCAT('Course with id ', targetCourseId, ' not found.');
        select errMsg as ErrorMessage;
        leave proc_label;
        /* signal SQLSTATE '45000' set MESSAGE_TEXT=errMsg; */
    end; end if;
    set srcCourseId = (select c_id from c_quiz where iid=quizId);
    SET SQL_SAFE_UPDATES = 0;
    start transaction;
    create temporary table tmp as select * from c_quiz where iid=quizId;
    alter table tmp modify iid int NULL;
    update tmp set iid=null, c_id=targetCourseId;
    insert into c_quiz select * from tmp;
    set newQuizId = last_insert_id();
    drop table tmp;
    update c_quiz set id=newQuizId where iid=newQuizId;
    create temporary table tmp as select * from c_quiz_rel_category where exercise_id=quizId;
    alter table tmp modify iid int NULL;
    update tmp set iid=null, c_id=targetCourseId, exercise_id=newQuizId;
    insert into c_quiz_rel_category select * from tmp;
    drop table tmp;
    if targetCourseId=srcCourseId then begin
        /* shallow-copy questions */
        create temporary table tmp as select * from c_quiz_rel_question where exercice_id=quizId;
        alter table tmp modify iid int NULL;
        update tmp set exercice_id=newQuizId, c_id=targetCourseId, iid=null;
        insert into c_quiz_rel_question select * from tmp;
        drop table tmp;
    end; else begin
        call CloneQuestions(quizId, newQuizId, targetCourseId);
    end; end if;
    COMMIT;
    select CONCAT('Quiz copied.  New quiz id is ', newQuizId) as Result;
end$$
DELIMITER ;
