drop procedure if exists CloneQuestions;
DELIMITER //
create procedure CloneQuestions(quizId int, newQuizId int, targetCourseId int)
begin
	declare done bool default false;
    declare qid, newQid, tid, n int default 0;
	declare qcur cursor for select question_id from c_quiz_rel_question where exercice_id=quizId;
    declare continue handler for NOT FOUND set done = true;
    SET SQL_SAFE_UPDATES = 0;
    open qcur;
    read_loop: LOOP
		FETCH qcur into qid;
        if done=true then
			LEAVE read_loop;
        end if;
        /* c_quiz_question */
        insert into c_quiz_question (c_id, question, description, ponderation, position, type, picture, level, extra, question_code)
			select q.c_id, q.question, q.description, q.ponderation, q.position, q.type, q.picture, q.level, q.extra, q.question_code
            from c_quiz_question q
            where q.iid=qid;
		set newQid = last_insert_id();
        update c_quiz_question set c_id=targetCourseId, id=newQid where iid=newQid;
        
        insert into c_quiz_rel_question select null, targetCourseId, t.question_order, newQid, newQuizId from c_quiz_rel_question t
			where t.question_id=qid and t.exercice_id=quizId;
		
        insert into c_quiz_question_option select null, targetCourseId, newQid, t.name, t.position 
			from c_quiz_question_option t where t.question_id=qid;
        set n = row_count();
        if n > 0 then begin
			set tid = last_insert_id();
			update c_quiz_question_option set id=tid where iid=tid;
        end; end if;
        
        insert into c_quiz_question_rel_category select null, targetCourseId, t.category_id, newQid
			from c_quiz_question_rel_category t where t.question_id=qid;
            
        create temporary table tmp as select * from c_quiz_answer where question_id=qid;
        alter table tmp modify iid int NULL;
        update tmp set iid=null, c_id=targetCourseId, question_id=newQid;
        insert into c_quiz_answer select * from tmp;
        update c_quiz_answer set id=iid where question_id=newQid;
    END LOOP;
    CLOSE qcur;
end;

DELIMITER ;

drop procedure if exists CloneQuiz;
DELIMITER //
create procedure CloneQuiz(quizId int, targetCourseId int)
begin
	declare n, newQuizId int;
    declare errMsg TEXT;
	declare EXIT HANDLER FOR SQLEXCEPTION
    begin
		GET DIAGNOSTICS CONDITION 1 @msg = MESSAGE_TEXT;
        select @msg as ErrorMsg;
		ROLLBACK;
    end;
    set n = (select count(*) from c_quiz where iid=quizId);
    if n<>1 then begin
		set errMsg = CONCAT('Quiz with id ', quizId, ' not found.');
		signal SQLSTATE '45000' set MESSAGE_TEXT= errMsg;
    end; end if;
    set n = (select count(*) from course where id=targetCourseId);
    if n<>1 then begin
		set errMsg = CONCAT('Course with id ', targetCourseId, ' not found.');
        signal SQLSTATE '45000' set MESSAGE_TEXT=errMsg;
    end; end if;
    SET SQL_SAFE_UPDATES = 0;
	start transaction;
    create temporary table tmp as select * from c_quiz where iid=quizId;
    alter table tmp modify iid int NULL;
    update tmp set iid=null, c_id=targetCourseId;
    insert into c_quiz select * from tmp;
    set newQuizId = last_insert_id();
    drop table tmp;
    update c_quiz set id=newQuizId where iid=newQuizId;
    create temporary table tmp as select * from c_quiz_rel_category where exercise_id=quizId;
    alter table tmp modify iid int NULL;
    update tmp set iid=null, c_id=targetCourseId, exercise_id=newQuizId;
    insert into c_quiz_rel_category select * from tmp;
    drop table tmp;
	/* shallow-copy questions */
	create temporary table tmp as select * from c_quiz_rel_question where exercice_id=quizId;
	alter table tmp modify iid int NULL;
	update tmp set exercice_id=newQuizId, c_id=targetCourseId, iid=null;
	insert into c_quiz_rel_question select * from tmp;
	drop table tmp;

    COMMIT;
    select CONCAT('Quiz copied.  New quiz id is ', newQuizId) as Result;
end;

DELIMITER ;

drop procedure if exists ResetQuizzes;
DELIMITER //
create procedure ResetQuizzes()
begin
	truncate c_quiz_answer;
    truncate c_quiz_rel_question;
    truncate c_quiz_rel_category;
    truncate c_quiz_question_rel_category;
    truncate c_quiz_question_category;
    truncate c_quiz_question_option;
    truncate c_quiz_question;
    truncate c_quiz;
end;
DELIMITER ;
